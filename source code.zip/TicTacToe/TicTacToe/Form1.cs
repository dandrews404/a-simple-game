﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {

        public enum Actor
        {
            X, O
        }
        Actor currentActor;
        Random rand = new Random();
        int theirWinCount;
        int myWinCount;
        List<Button> buttons;
        public Form1()
        {
            InitializeComponent();
            newGame();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void MyTurn(object sender, EventArgs e)
        {
            if(buttons.Count > 0)
            {
                /*
                 I promise in the real world I dont make my decisions like this
                 */
                int myDecision = rand.Next(buttons.Count);
                buttons[myDecision].Enabled = false;
                currentActor = Actor.O;
                buttons[myDecision].Text = currentActor.ToString();
                buttons[myDecision].BackColor = Color.AliceBlue;
                buttons.RemoveAt(myDecision);
                checkGame();
                AppTimer.Stop();

            }
        }

        private void theyClicked(object sender, EventArgs e)
        {
            var buttonSender = (Button)sender;
            currentActor = Actor.X;
            buttonSender.Text = currentActor.ToString();
            buttonSender.Enabled = false;
            buttonSender.BackColor = Color.AliceBlue;
            buttons.Remove(buttonSender);
            checkGame();
            AppTimer.Start();
        }

        private void startNewGame(object sender, EventArgs e)
        {
            newGame();
        }

        private void checkGame()
        {
            if(button1.Text == "X" && button2.Text == "X" && button3.Text == "X"
               || button4.Text == "X" && button5.Text == "X" && button6.Text == "X"
               || button7.Text == "X" && button9.Text == "X" && button8.Text == "X"
               || button1.Text == "X" && button6.Text == "X" && button9.Text == "X"
               || button2.Text == "X" && button5.Text == "X" && button8.Text == "X"
               || button3.Text == "X" && button4.Text == "X" && button7.Text == "X"
               || button1.Text == "X" && button5.Text == "X" && button7.Text == "X"
               || button3.Text == "X" && button5.Text == "X" && button9.Text == "X")
            {
                //keeping here because of windows 11 bug
                AppTimer.Stop();
                MessageBox.Show("You Win!", "I hate to admit it but...");
                theirWinCount++;
                label1.Text = "Your Wins: " + theirWinCount;
                newGame();
            }
            else if(button1.Text == "O" && button2.Text == "O" && button3.Text == "O"
               || button4.Text == "O" && button5.Text == "O" && button6.Text == "O"
               || button7.Text == "O" && button9.Text == "O" && button8.Text == "O"
               || button1.Text == "O" && button6.Text == "O" && button9.Text == "O"
               || button2.Text == "O" && button5.Text == "O" && button8.Text == "O"
               || button3.Text == "O" && button4.Text == "O" && button7.Text == "O"
               || button1.Text == "O" && button5.Text == "O" && button7.Text == "O"
               || button3.Text == "O" && button5.Text == "O" && button9.Text == "O")
            {
                AppTimer.Stop();
                MessageBox.Show("I Win!", "Guess what...");
                myWinCount++;
                label2.Text = "My Wins: " + myWinCount;
                newGame();
            }
        }
        
        private void newGame()
        {
            buttons = new List<Button> { button1, button2, button3, button4, button5, button6, button7, button8, button9 };

            foreach(Button i in buttons)
            {
                i.Enabled = true;
                i.Text = "Click Here!";
                i.BackColor = DefaultBackColor;
            }

        }
    }
}
